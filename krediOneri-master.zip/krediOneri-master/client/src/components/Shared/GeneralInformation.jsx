function GeneralInformation() {
    return ( <div>General</div> );
}

export default GeneralInformation;